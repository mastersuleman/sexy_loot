---
-- SexyLoot Options Panel
-- Comprehensive GUI for configuring the addon

local _, private = ...;

-- Create options panel
local optionsPanel = CreateFrame("Frame", "SexyLootOptions", UIParent);
optionsPanel.name = "SexyLoot";
InterfaceOptions_AddCategory(optionsPanel);

-- Create scrollable content frame
local scrollFrame = CreateFrame("ScrollFrame", nil, optionsPanel, "UIPanelScrollFrameTemplate");
scrollFrame:SetPoint("TOPLEFT", 10, -10);
scrollFrame:SetPoint("BOTTOMRIGHT", -30, 10);

local content = CreateFrame("Frame", nil, scrollFrame);
content:SetSize(580, 800);
scrollFrame:SetScrollChild(content);

-- Title
local title = content:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
title:SetPoint("TOPLEFT", 16, -16);
title:SetText("|cffff69b4SexyLoot|r Configuration");

-- Button row at top
local lockButton = CreateFrame("Button", nil, content, "UIPanelButtonTemplate");
lockButton:SetPoint("TOPRIGHT", -20, -16);
lockButton:SetSize(100, 22);
lockButton:SetScript("OnClick", function(self)
	SexyLootDB.locked = not SexyLootDB.locked;
	if SexyLootDB.locked then
		self:SetText("Unlock Frames");
		print("|cffff69b4SexyLoot:|r Frames locked");
	else
		self:SetText("Lock Frames");
		print("|cffff69b4SexyLoot:|r Frames unlocked - drag to reposition");
		SexyLoot_ShowTestAlerts();
	end
end);

-- Test button
local testButton = CreateFrame("Button", nil, content, "UIPanelButtonTemplate");
testButton:SetPoint("RIGHT", lockButton, "LEFT", -5, 0);
testButton:SetSize(100, 22);
testButton:SetText("Test Alerts");
testButton:SetScript("OnClick", function()
	SexyLoot_ShowTestAlerts();
end);

-- Reset position button
local resetButton = CreateFrame("Button", nil, content, "UIPanelButtonTemplate");
resetButton:SetPoint("RIGHT", testButton, "LEFT", -5, 0);
resetButton:SetSize(100, 22);
resetButton:SetText("Reset Position");
resetButton:SetScript("OnClick", function()
	SexyLootDB.positions = nil;
	SexyLootDB.anchorPoint = nil;
	SexyLootDB.anchorX = nil;
	SexyLootDB.anchorY = nil;
	print("|cffff69b4SexyLoot:|r Positions reset to default");
	LootAlertFrameMixIn:AdjustAnchors();
end);

-- Subtitle
local subtitle = content:CreateFontString(nil, "ARTWORK", "GameFontHighlight");
subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8);
subtitle:SetText("Customize your loot notifications");

local yOffset = -60;

-- Display Settings Section
local displayHeader = content:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
displayHeader:SetPoint("TOPLEFT", 16, yOffset);
displayHeader:SetText("Display Settings");
yOffset = yOffset - 30;

-- Scale slider
local scaleSlider = CreateFrame("Slider", "SexyLootScaleSlider", content, "OptionsSliderTemplate");
scaleSlider:SetPoint("TOPLEFT", 26, yOffset);
scaleSlider:SetMinMaxValues(0.3, 2.0);
scaleSlider:SetValueStep(0.05);
scaleSlider:SetWidth(200);
_G[scaleSlider:GetName().."Text"]:SetText("Alert Scale");
_G[scaleSlider:GetName().."Low"]:SetText("0.3");
_G[scaleSlider:GetName().."High"]:SetText("2.0");
scaleSlider:SetScript("OnValueChanged", function(self, value)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.scale = value;
	private.config.scale = value;
	_G[self:GetName().."Text"]:SetText(string.format("Alert Scale: %.2f", value));
end);
yOffset = yOffset - 50;

-- Number of toasts slider
local numToastsSlider = CreateFrame("Slider", "SexyLootNumToastsSlider", content, "OptionsSliderTemplate");
numToastsSlider:SetPoint("TOPLEFT", 26, yOffset);
numToastsSlider:SetMinMaxValues(1, 8);
numToastsSlider:SetValueStep(1);
numToastsSlider:SetWidth(200);
_G[numToastsSlider:GetName().."Text"]:SetText("Max Toasts");
_G[numToastsSlider:GetName().."Low"]:SetText("1");
_G[numToastsSlider:GetName().."High"]:SetText("8");
numToastsSlider:SetScript("OnValueChanged", function(self, value)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.numbuttons = value;
	private.config.numbuttons = value;
	_G[self:GetName().."Text"]:SetText(string.format("Max Toasts: %d", value));
end);
yOffset = yOffset - 50;

-- Toast padding slider
local paddingSlider = CreateFrame("Slider", "SexyLootPaddingSlider", content, "OptionsSliderTemplate");
paddingSlider:SetPoint("TOPLEFT", 26, yOffset);
paddingSlider:SetMinMaxValues(0, 20);
paddingSlider:SetValueStep(1);
paddingSlider:SetWidth(200);
_G[paddingSlider:GetName().."Text"]:SetText("Toast Spacing");
_G[paddingSlider:GetName().."Low"]:SetText("0");
_G[paddingSlider:GetName().."High"]:SetText("20");
paddingSlider:SetScript("OnValueChanged", function(self, value)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.offset_x = value;
	private.config.offset_x = value;
	_G[self:GetName().."Text"]:SetText(string.format("Toast Spacing: %d pixels", value));
end);
yOffset = yOffset - 50;

-- Display duration slider
local durationSlider = CreateFrame("Slider", "SexyLootDurationSlider", content, "OptionsSliderTemplate");
durationSlider:SetPoint("TOPLEFT", 26, yOffset);
durationSlider:SetMinMaxValues(0.1, 2.0);
durationSlider:SetValueStep(0.1);
durationSlider:SetWidth(200);
_G[durationSlider:GetName().."Text"]:SetText("Update Speed");
_G[durationSlider:GetName().."Low"]:SetText("0.1s");
_G[durationSlider:GetName().."High"]:SetText("2.0s");
durationSlider:SetScript("OnValueChanged", function(self, value)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.time = value;
	private.config.time = value;
	_G[self:GetName().."Text"]:SetText(string.format("Update Speed: %.1f sec", value));
end);
yOffset = yOffset - 60;

-- General Settings Section
local generalHeader = content:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
generalHeader:SetPoint("TOPLEFT", 16, yOffset);
generalHeader:SetText("General Settings");
yOffset = yOffset - 30;

-- Enable Sound checkbox
local soundCheck = CreateFrame("CheckButton", "SexyLootSoundCheck", content, "UICheckButtonTemplate");
soundCheck:SetPoint("TOPLEFT", 20, yOffset);
_G[soundCheck:GetName().."Text"]:SetText("Enable Sounds");
soundCheck:SetScript("OnClick", function(self)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.sound = self:GetChecked();
	private.config.sound = self:GetChecked();
end);
yOffset = yOffset - 30;

-- Custom Coin Sound checkbox
local coinSoundCheck = CreateFrame("CheckButton", "SexyLootCoinSoundCheck", content, "UICheckButtonTemplate");
coinSoundCheck:SetPoint("TOPLEFT", 20, yOffset);
_G[coinSoundCheck:GetName().."Text"]:SetText("Use coin jingle for money loot");
coinSoundCheck:SetScript("OnClick", function(self)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.coinSound = self:GetChecked();
end);
yOffset = yOffset - 30;

-- Enable Animations checkbox
local animCheck = CreateFrame("CheckButton", "SexyLootAnimCheck", content, "UICheckButtonTemplate");
animCheck:SetPoint("TOPLEFT", 20, yOffset);
_G[animCheck:GetName().."Text"]:SetText("Enable Animations");
animCheck:SetScript("OnClick", function(self)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.anims = self:GetChecked();
	private.config.anims = self:GetChecked();
end);
yOffset = yOffset - 40;

-- Tracking Settings Section
local trackingHeader = content:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
trackingHeader:SetPoint("TOPLEFT", 16, yOffset);
trackingHeader:SetText("Tracking Settings");
yOffset = yOffset - 30;

-- Create two columns for tracking checkboxes
local leftColumn = 20;
local rightColumn = 280;
local columnYOffset = yOffset;

-- Left column tracking options
local trackingOptions = {
	{var = "looting", text = "Track Looting", column = leftColumn},
	{var = "creating", text = "Track Crafting", column = leftColumn},
	{var = "rolling", text = "Track Rolling", column = leftColumn},
	{var = "money", text = "Track Money Changes", column = leftColumn},
	{var = "trades", text = "Track Trades", column = rightColumn, y = columnYOffset},
	{var = "mail", text = "Track Mail", column = rightColumn},
	{var = "recipes", text = "Track Recipe Learning", column = rightColumn},
	{var = "honor", text = "Track Honor/PvP", column = rightColumn},
};

for i, option in ipairs(trackingOptions) do
	local check = CreateFrame("CheckButton", "SexyLoot"..option.var.."Check", content, "UICheckButtonTemplate");
	
	if option.y then
		yOffset = option.y;
	end
	
	check:SetPoint("TOPLEFT", option.column, yOffset);
	_G[check:GetName().."Text"]:SetText(option.text);
	check:SetScript("OnClick", function(self)
		SexyLootDB.config = SexyLootDB.config or {};
		SexyLootDB.config[option.var] = self:GetChecked();
		private.config[option.var] = self:GetChecked();
	end);
	
	if option.column == leftColumn then
		yOffset = yOffset - 30;
	end
end

yOffset = yOffset - 40;

-- Quality Filter Settings Section
local qualityHeader = content:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
qualityHeader:SetPoint("TOPLEFT", 16, yOffset);
qualityHeader:SetText("Quality Filters");
yOffset = yOffset - 30;

-- Ignore quality level checkbox
local ignoreQualityCheck = CreateFrame("CheckButton", "SexyLootIgnoreQualityCheck", content, "UICheckButtonTemplate");
ignoreQualityCheck:SetPoint("TOPLEFT", 20, yOffset);
_G[ignoreQualityCheck:GetName().."Text"]:SetText("Show all item qualities");
ignoreQualityCheck:SetScript("OnClick", function(self)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.ignore_level = self:GetChecked();
	private.config.ignore_level = self:GetChecked();
end);
yOffset = yOffset - 40;

-- Minimum quality for low level slider
local lowQualitySlider = CreateFrame("Slider", "SexyLootLowQualitySlider", content, "OptionsSliderTemplate");
lowQualitySlider:SetPoint("TOPLEFT", 26, yOffset);
lowQualitySlider:SetMinMaxValues(0, 5);
lowQualitySlider:SetValueStep(1);
lowQualitySlider:SetWidth(200);
_G[lowQualitySlider:GetName().."Text"]:SetText("Min Quality (Low Level)");
_G[lowQualitySlider:GetName().."Low"]:SetText("Poor");
_G[lowQualitySlider:GetName().."High"]:SetText("Legendary");

local qualityNames = {"Poor", "Common", "Uncommon", "Rare", "Epic", "Legendary"};
lowQualitySlider:SetScript("OnValueChanged", function(self, value)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.low_level = value;
	private.config.low_level = value;
	_G[self:GetName().."Text"]:SetText(string.format("Min Quality (Low Level): %s", qualityNames[value + 1]));
end);
yOffset = yOffset - 50;

-- Minimum quality for max level slider
local maxQualitySlider = CreateFrame("Slider", "SexyLootMaxQualitySlider", content, "OptionsSliderTemplate");
maxQualitySlider:SetPoint("TOPLEFT", 26, yOffset);
maxQualitySlider:SetMinMaxValues(0, 5);
maxQualitySlider:SetValueStep(1);
maxQualitySlider:SetWidth(200);
_G[maxQualitySlider:GetName().."Text"]:SetText("Min Quality (Level 80)");
_G[maxQualitySlider:GetName().."Low"]:SetText("Poor");
_G[maxQualitySlider:GetName().."High"]:SetText("Legendary");
maxQualitySlider:SetScript("OnValueChanged", function(self, value)
	SexyLootDB.config = SexyLootDB.config or {};
	SexyLootDB.config.max_level = value;
	private.config.max_level = value;
	_G[self:GetName().."Text"]:SetText(string.format("Min Quality (Level 80): %s", qualityNames[value + 1]));
end);
yOffset = yOffset - 60;

-- Test Buttons Section
local testHeader = content:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
testHeader:SetPoint("TOPLEFT", 16, yOffset);
testHeader:SetText("Test Alerts");
yOffset = yOffset - 30;

-- Individual test buttons
local testTypes = {
	{name = "Legendary", func = "TestLegendary"},
	{name = "Epic", func = "TestEpic"},
	{name = "Money Gain", func = "TestMoneyGain"},
	{name = "Money Loss", func = "TestMoneyLoss"},
	{name = "Recipe", func = "TestRecipe"},
	{name = "Common", func = "TestCommon"},
};

local xPos = 20;
for i, test in ipairs(testTypes) do
	local btn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate");
	btn:SetPoint("TOPLEFT", xPos, yOffset);
	btn:SetSize(85, 22);
	btn:SetText(test.name);
	btn:SetScript("OnClick", function()
		_G["SexyLoot_"..test.func]();
	end);
	xPos = xPos + 90;
	if i == 3 then
		xPos = 20;
		yOffset = yOffset - 30;
	end
end

-- Initialize values on panel show
content:SetScript("OnShow", function(self)
	-- Load saved settings
	if SexyLootDB then
		lockButton:SetText(SexyLootDB.locked and "Unlock Frames" or "Lock Frames");
		
		if SexyLootDB.config then
			-- Display settings
			scaleSlider:SetValue(SexyLootDB.config.scale or private.config.scale or 0.75);
			numToastsSlider:SetValue(SexyLootDB.config.numbuttons or private.config.numbuttons or 8);
			paddingSlider:SetValue(SexyLootDB.config.offset_x or private.config.offset_x or 2);
			durationSlider:SetValue(SexyLootDB.config.time or private.config.time or 0.3);
			
			-- General settings
			soundCheck:SetChecked(SexyLootDB.config.sound ~= false);
			coinSoundCheck:SetChecked(SexyLootDB.config.coinSound);
			animCheck:SetChecked(SexyLootDB.config.anims ~= false);
			
			-- Tracking settings
			for _, option in ipairs(trackingOptions) do
				local check = _G["SexyLoot"..option.var.."Check"];
				if check then
					check:SetChecked(SexyLootDB.config[option.var] ~= false);
				end
			end
			
			-- Quality settings
			ignoreQualityCheck:SetChecked(SexyLootDB.config.ignore_level);
			lowQualitySlider:SetValue(SexyLootDB.config.low_level or private.config.low_level or 1);
			maxQualitySlider:SetValue(SexyLootDB.config.max_level or private.config.max_level or 4);
		else
			-- Default values
			scaleSlider:SetValue(0.75);
			numToastsSlider:SetValue(8);
			paddingSlider:SetValue(2);
			durationSlider:SetValue(0.3);
			soundCheck:SetChecked(true);
			coinSoundCheck:SetChecked(false);
			animCheck:SetChecked(true);
			
			for _, option in ipairs(trackingOptions) do
				local check = _G["SexyLoot"..option.var.."Check"];
				if check then
					check:SetChecked(true);
				end
			end
			
			ignoreQualityCheck:SetChecked(false);
			lowQualitySlider:SetValue(1);
			maxQualitySlider:SetValue(4);
		end
	end
end);

-- Test alert functions
function SexyLoot_ShowTestAlerts()
	local testData = {
		{
			name = "Thunderfury, Blessed Blade of the Windseeker",
			quality = 5,
			texture = "Interface\\Icons\\INV_Sword_39",
			label = LEGENDARY_ITEM_LOOT_LABEL,
			toast = "legendarytoast"
		},
		{
			name = "50 Gold",
			quality = 6,
			label = "You received:",
			toast = "moneytoast",
			money = 500000
		},
		{
			name = "Epic Sword of Testing",
			quality = 4,
			texture = "Interface\\Icons\\INV_Sword_01",
			label = YOU_RECEIVED_LABEL,
			toast = "heroictoast"
		}
	};
	
	for i, data in ipairs(testData) do
		data.link = "|cff9d9d9d|Hitem:7073:0:0:0:0:0:0:0:0:0:0|h[Test Item]|h|r";
		LootAlertFrameMixIn:AddAlert(data.name, data.link, data.quality, data.texture, nil, true, data.label, data.toast, nil, nil, nil, data.money);
	end
end

function SexyLoot_TestLegendary()
	local data = {
		name = "Thunderfury, Blessed Blade of the Windseeker",
		quality = 5,
		texture = "Interface\\Icons\\INV_Sword_39",
		label = LEGENDARY_ITEM_LOOT_LABEL,
		toast = "legendarytoast",
		link = "|cffff8000|Hitem:19019:0:0:0:0:0:0:0:0:0:0|h[Thunderfury]|h|r"
	};
	LootAlertFrameMixIn:AddAlert(data.name, data.link, data.quality, data.texture, nil, true, data.label, data.toast);
end

function SexyLoot_TestEpic()
	local data = {
		name = "Shadowmourne",
		quality = 4,
		texture = "Interface\\Icons\\INV_Axe_113",
		label = YOU_RECEIVED_LABEL,
		toast = "heroictoast",
		link = "|cffa335ee|Hitem:49623:0:0:0:0:0:0:0:0:0:0|h[Shadowmourne]|h|r"
	};
	LootAlertFrameMixIn:AddAlert(data.name, data.link, data.quality, data.texture, nil, true, data.label, data.toast);
end

function SexyLoot_TestMoneyGain()
	local data = {
		name = "15 Gold 32 Silver",
		quality = 6,
		label = "You received:",
		toast = "moneytoast",
		money = 153200,
		link = false
	};
	LootAlertFrameMixIn:AddAlert(data.name, data.link, data.quality, false, nil, true, data.label, data.toast, nil, nil, nil, data.money);
end

function SexyLoot_TestMoneyLoss()
	local data = {
		name = "5 Gold 50 Silver",
		quality = 0,
		label = "You spent:",
		toast = "moneytoast",
		money = 55000,
		link = false,
		isLoss = true
	};
	LootAlertFrameMixIn:AddAlert(data.name, data.link, data.quality, false, nil, true, data.label, data.toast, nil, nil, nil, data.money, nil, true);
end

function SexyLoot_TestRecipe()
	local data = {
		name = "Flask of the Titans",
		quality = 3,
		texture = "Interface\\AddOns\\SexyLoot\\assets\\UI-TradeSkill-Circle",
		label = NEW_RECIPE_LEARNED_TITLE,
		toast = "recipetoast",
		link = "|cff1eff00|Hitem:13510:0:0:0:0:0:0:0:0:0:0|h[Flask Recipe]|h|r",
		subType = TOAST_PROFESSION_ALCHEMY
	};
	LootAlertFrameMixIn:AddAlert(data.name, data.link, data.quality, data.texture, nil, true, data.label, data.toast, nil, nil, nil, nil, data.subType);
end

function SexyLoot_TestCommon()
	local data = {
		name = "Linen Cloth",
		quality = 1,
		texture = "Interface\\Icons\\INV_Fabric_Linen_01",
		label = YOU_RECEIVED_LABEL,
		toast = "commontoast",
		link = "|cffffffff|Hitem:2589:0:0:0:0:0:0:0:0:0:0|h[Linen Cloth]|h|r",
		count = 5
	};
	LootAlertFrameMixIn:AddAlert(data.name, data.link, data.quality, data.texture, data.count, true, data.label, data.toast);
end

-- Slash commands
SLASH_SEXYLOOT1 = "/sexyloot";
SLASH_SEXYLOOT2 = "/sl";
SlashCmdList["SEXYLOOT"] = function(msg)
	msg = msg:lower();
	if msg == "lock" then
		SexyLootDB.locked = true;
		print("|cffff69b4SexyLoot:|r Frames locked");
	elseif msg == "unlock" then
		SexyLootDB.locked = false;
		print("|cffff69b4SexyLoot:|r Frames unlocked - drag to reposition");
		SexyLoot_ShowTestAlerts();
	elseif msg == "test" then
		SexyLoot_ShowTestAlerts();
	elseif msg == "reset" then
		SexyLootDB.positions = nil;
		SexyLootDB.anchorPoint = nil;
		SexyLootDB.anchorX = nil;
		SexyLootDB.anchorY = nil;
		print("|cffff69b4SexyLoot:|r Positions reset to default");
	elseif msg == "config" or msg == "options" or msg == "" then
		InterfaceOptionsFrame_OpenToCategory("SexyLoot");
	else
		print("|cffff69b4SexyLoot|r commands:");
		print("  /sl config - Open configuration");
		print("  /sl lock - Lock frames");
		print("  /sl unlock - Unlock frames for dragging");
		print("  /sl test - Show test alerts");
		print("  /sl reset - Reset positions to default");
	end
end;